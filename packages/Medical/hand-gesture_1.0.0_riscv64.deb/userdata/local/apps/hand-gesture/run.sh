#!/bin/sh
export LD_LIBRARY_PATH=/mnt/system/lib:/mnt/system/usr/lib:/mnt/system/usr/lib/3rd:/mnt/system/lib/3rd:/lib:/usr/lib
exec /usr/local/bin/hand-gesture /userdata/local/models/hand_detector_cv181x_int8.cvimodel /userdata/local/models/hand_landmarks_detector_cv181x_int8.cvimodel /userdata/local/models/gesture_embedder_cv181x_int8.cvimodel /userdata/local/models/canned_gesture_classifier_cv181x_int8.cvimodel
