#!/bin/sh
APP_ID=groove-features
CONFIG=/userdata/local/apps/${APP_ID}.config.json
json_value() {
  key="$1"
  [ -r "$CONFIG" ] || return 0
  if command -v jsonfilter >/dev/null 2>&1; then
    jsonfilter -i "$CONFIG" -e "@.$key" 2>/dev/null
  elif command -v node >/dev/null 2>&1; then
    node -e 'try { const fs = require("fs"); const v = JSON.parse(fs.readFileSync(process.argv[1], "utf8"))[process.argv[2]]; if (v !== undefined && v !== null) fs.writeSync(1, String(v)); } catch (_) {}' "$CONFIG" "$key"
  fi
}
threshold_percent="$(json_value binary_threshold)"
mqtt_topic="$(json_value mqtt_topic)"
udp_enabled="$(json_value udp_enabled)"
[ -n "$threshold_percent" ] || threshold_percent=50
[ -n "$mqtt_topic" ] || mqtt_topic=recamera/groove-features/results
binary_threshold="$(awk -v value="$threshold_percent" 'BEGIN { printf "%d", value * 2.55 + 0.5 }')"

# 传统 UDP 外发：默认关闭（Studio 优先，保留子流）；仅当配置显式打开时启用。
udp_ip=""
udp_port=""
if [ "$udp_enabled" = "true" ] || [ "$udp_enabled" = "1" ]; then
  udp_ip=192.168.2.101
  udp_port=5001
fi

export LD_LIBRARY_PATH=/userdata/local/models:/mnt/system/lib:/mnt/system/usr/lib:/mnt/system/usr/lib/3rd:/mnt/system/lib/3rd:/lib:/usr/lib
exec /usr/local/bin/$APP_ID "$udp_ip" "$udp_port" "$binary_threshold" "$mqtt_topic"
