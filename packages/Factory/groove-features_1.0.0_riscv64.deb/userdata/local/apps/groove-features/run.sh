#!/bin/sh
# groove-features: camera-based groove/bar counting with OpenCV, streaming
# JPEG + bbox dets over UDP. The binary opens the camera itself through the
# sscma Device API (channel 0, 640x480).
#
# No NPU model is needed; this daemon is a pure OpenCV pipeline.
#
# libopencv_core.so.4.5 / libopencv_imgproc.so.4.5 are not present in
# /mnt/system/lib, so the package ships them under /userdata/local/models
# and picks them up via LD_LIBRARY_PATH below.

APP_ID=groove-features
DAEMON=/usr/local/bin/$APP_ID

export LD_LIBRARY_PATH=/userdata/local/models:/mnt/system/lib:/mnt/system/usr/lib:/mnt/system/usr/lib/3rd:/mnt/system/lib/3rd:/lib:/usr/lib

# Default UDP target per main.cpp (192.168.2.101:5001); pass explicit args
# so the receiver target is obvious in the log line.
exec "$DAEMON" 192.168.2.101 5001
