#!/bin/sh
CONFIG=/userdata/local/apps/ppocr-reader.config.json
json_value() {
  key="$1"
  [ -r "$CONFIG" ] || return 0
  if command -v jsonfilter >/dev/null 2>&1; then
    jsonfilter -i "$CONFIG" -e "@.$key" 2>/dev/null
  elif command -v node >/dev/null 2>&1; then
    node -e 'try { const fs = require("fs"); const v = JSON.parse(fs.readFileSync(process.argv[1], "utf8"))[process.argv[2]]; if (v !== undefined && v !== null) fs.writeSync(1, String(v)); } catch (_) {}' "$CONFIG" "$key"
  fi
}
mqtt_topic="$(json_value mqtt_topic)"
mqtt_enabled="$(json_value mqtt_enabled)"
[ -n "$mqtt_topic" ] || mqtt_topic=recamera/ppocr/texts
[ -n "$mqtt_enabled" ] || mqtt_enabled=true
[ "$mqtt_enabled" = "true" ] || no_mqtt=--no-mqtt

export LD_LIBRARY_PATH=/userdata/local/apps/ppocr-reader/lib:/mnt/system/lib:/mnt/system/usr/lib:/mnt/system/usr/lib/3rd:/mnt/system/lib/3rd:/lib:/usr/lib
exec /usr/local/bin/ppocr-reader \
  --det-model /userdata/local/models/ppocr_det_cv181x_mix.cvimodel \
  --rec-model /userdata/local/models/ppocr_rec_cv181x_bf16.cvimodel \
  --dict /userdata/local/dict/ppocr_keys_v1.txt \
  --mqtt-host localhost \
  --mqtt-port 1883 \
  --mqtt-topic "$mqtt_topic" \
  $no_mqtt
