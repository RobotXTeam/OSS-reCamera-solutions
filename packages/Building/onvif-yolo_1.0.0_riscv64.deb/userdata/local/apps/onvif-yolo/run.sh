#!/bin/sh
export LD_LIBRARY_PATH=/mnt/system/lib:/mnt/system/usr/lib:/mnt/system/usr/lib/3rd:/mnt/system/lib/3rd:/lib:/usr/lib
exec /usr/local/bin/onvif-yolo /userdata/local/models/onvif-yolo_detection.cvimodel 0.60 2 8554 live 8080
