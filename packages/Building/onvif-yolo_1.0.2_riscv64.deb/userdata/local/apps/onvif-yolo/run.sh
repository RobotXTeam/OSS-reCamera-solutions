#!/bin/sh
CONFIG=/userdata/local/apps/onvif-yolo.config.json
json_value() {
  key="$1"
  [ -r "$CONFIG" ] || return 0
  if command -v jsonfilter >/dev/null 2>&1; then
    jsonfilter -i "$CONFIG" -e "@.$key" 2>/dev/null
  elif command -v node >/dev/null 2>&1; then
    node -e 'try { const fs = require("fs"); const v = JSON.parse(fs.readFileSync(process.argv[1], "utf8"))[process.argv[2]]; if (v !== undefined && v !== null) fs.writeSync(1, String(v)); } catch (_) {}' "$CONFIG" "$key"
  fi
}
confidence_percent="$(json_value confidence)"
[ -n "$confidence_percent" ] || confidence_percent=60
confidence="$(awk -v value="$confidence_percent" 'BEGIN { printf "%.2f", value / 100 }')"

export LD_LIBRARY_PATH=/mnt/system/lib:/mnt/system/usr/lib:/mnt/system/usr/lib/3rd:/mnt/system/lib/3rd:/lib:/usr/lib
exec /usr/local/bin/onvif-yolo /userdata/local/models/onvif-yolo_detection.cvimodel "$confidence" 2 8554 live 8080
